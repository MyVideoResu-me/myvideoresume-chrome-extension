# myvideoresume-chrome-extension
Chrome Plugin Extension for AI Resume Generation

Zip the application in the root directory. 
```
zip -r myvideoresume.zip * 
```