# myvideoresume-chrome-extension
Chrome Plugin Extension for AI Resume Generation
